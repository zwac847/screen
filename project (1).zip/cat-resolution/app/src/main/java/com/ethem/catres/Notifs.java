package com.ethem.catres;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public class Notifs {

    static final int ID = 5;

    private static PendingIntent pi(Context c, String action, long token) {
        Intent i = new Intent(c, ActionReceiver.class);
        i.setAction(action);
        i.putExtra("t", token);
        return PendingIntent.getBroadcast(c, action.hashCode(), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void show(Context c, long token, boolean confirm) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("res", "Ekran boyutu",
                NotificationManager.IMPORTANCE_HIGH));
        Notification.Builder b = new Notification.Builder(c, "res")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true)
                .setContentTitle(confirm ? "Ekran boyutu değişti" : "Ekran daraltıldı")
                .setContentText(confirm
                        ? Ops.SECONDS + " sn içinde düzgünse KALSIN'a bas, yoksa kendiliğinden geri alınır"
                        : "Bitince SIFIRLA'ya bas");
        b.addAction(0, "SIFIRLA", pi(c, "RESET", token));
        if (confirm) b.addAction(0, "KALSIN", pi(c, "KEEP", token));
        nm.notify(ID, b.build());
    }

    static void cancel(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.cancel(ID);
    }

    static void warnAfterBoot(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("res", "Ekran boyutu",
                NotificationManager.IMPORTANCE_HIGH));
        Notification n = new Notification.Builder(c, "res")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("Ekran daraltılmış olabilir")
                .setContentText("Shizuku'yu başlat, uygulamayı aç ve SIFIRLA'ya bas")
                .build();
        nm.notify(ID + 1, n);
    }
}
