package com.ethem.catres;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (Ops.prefs(ctx).getBoolean("active", false)) {
            Notifs.warnAfterBoot(ctx);
        }
    }
}
