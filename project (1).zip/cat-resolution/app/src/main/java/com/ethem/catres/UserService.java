package com.ethem.catres;

import android.os.SystemClock;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.MotionEvent;

import java.lang.reflect.Method;

/**
 * Shizuku ile kabuk (shell) yetkisiyle ayri bir surecte calisir.
 * Gelen dokunmalari belirtilen sanal ekrana enjekte eder.
 */
public class UserService extends IUserService.Stub {

    private Object inputManager;
    private Method injectMethod;
    private int injectArgc;
    private Method setDisplayId;
    private boolean ready = false;

    public UserService() {
        try {
            init();
        } catch (Throwable t) {
            ready = false;
        }
    }

    private void init() throws Exception {
        Object target = null;
        try {
            Class<?> g = Class.forName("android.hardware.input.InputManagerGlobal");
            target = g.getMethod("getInstance").invoke(null);
        } catch (Throwable ignored) {
        }
        if (target == null) {
            Class<?> m = Class.forName("android.hardware.input.InputManager");
            target = m.getMethod("getInstance").invoke(null);
        }
        inputManager = target;
        for (Method m : target.getClass().getMethods()) {
            if (!m.getName().equals("injectInputEvent")) continue;
            Class<?>[] p = m.getParameterTypes();
            if (p.length >= 2 && p[0] == InputEvent.class && p[1] == int.class) {
                if (injectMethod == null || p.length < injectArgc) {
                    injectMethod = m;
                    injectArgc = p.length;
                }
            }
        }
        if (injectMethod == null) throw new IllegalStateException("injectInputEvent yok");
        setDisplayId = MotionEvent.class.getMethod("setDisplayId", int.class);
        ready = true;
    }

    @Override
    public void destroy() {
        System.exit(0);
    }

    @Override
    public void exit() {
        destroy();
    }

    @Override
    public void touch(int action, int count, int[] ids, float[] xs, float[] ys,
                      long downTime, long eventTime, int displayId) {
        if (!ready || count <= 0) return;
        MotionEvent.PointerProperties[] props = new MotionEvent.PointerProperties[count];
        MotionEvent.PointerCoords[] coords = new MotionEvent.PointerCoords[count];
        for (int i = 0; i < count; i++) {
            props[i] = new MotionEvent.PointerProperties();
            props[i].id = ids[i];
            props[i].toolType = MotionEvent.TOOL_TYPE_FINGER;
            coords[i] = new MotionEvent.PointerCoords();
            coords[i].x = xs[i];
            coords[i].y = ys[i];
            coords[i].pressure = 1f;
            coords[i].size = 1f;
        }
        long now = SystemClock.uptimeMillis();
        MotionEvent ev = null;
        try {
            ev = MotionEvent.obtain(downTime, now, action, count, props, coords,
                    0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0);
            setDisplayId.invoke(ev, displayId);
            if (injectArgc == 2) {
                injectMethod.invoke(inputManager, ev, 0);
            } else {
                injectMethod.invoke(inputManager, ev, 0, -1);
            }
        } catch (Throwable ignored) {
        } finally {
            if (ev != null) ev.recycle();
        }
    }
}
