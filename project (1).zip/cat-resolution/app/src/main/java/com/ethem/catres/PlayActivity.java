package com.ethem.catres;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rikka.shizuku.Shizuku;

/**
 * Oyunu gizli bir sanal ekranda (ornegin 4:3) calistirir ve o goruntuyu
 * tum ekrana gererek gosterir. Dokunmalar sanal ekrana aktarilir.
 */
public class PlayActivity extends Activity implements SurfaceHolder.Callback {

    private SurfaceView sv;
    private VirtualDisplay vd;
    private volatile IUserService svc;
    private Shizuku.UserServiceArgs args;
    private int vw, vh;
    private String pkg;
    private boolean firstLaunch = true;
    private long lastBack = 0;
    private boolean warned = false;
    private final ExecutorService ex = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName n, IBinder b) {
            svc = IUserService.Stub.asInterface(b);
        }

        @Override
        public void onServiceDisconnected(ComponentName n) {
            svc = null;
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        pkg = getIntent().getStringExtra("pkg");
        int rw = getIntent().getIntExtra("rw", 4);
        int rh = getIntent().getIntExtra("rh", 3);
        vh = 1080;
        vw = vh * rw / rh;
        vw -= vw % 2;

        sv = new SurfaceView(this);
        sv.getHolder().setFixedSize(vw, vh);
        sv.getHolder().addCallback(this);
        sv.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                forward(e);
                return true;
            }
        });
        setContentView(sv);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        getWindow().setAttributes(lp);
        getWindow().setDecorFitsSystemWindows(false);
        WindowInsetsController c = getWindow().getInsetsController();
        if (c != null) {
            c.hide(WindowInsets.Type.systemBars());
            c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        }

        try {
            args = new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), UserService.class.getName()))
                    .daemon(false)
                    .processNameSuffix("input")
                    .debuggable(false)
                    .version(1);
            Shizuku.bindUserService(args, conn);
        } catch (Throwable t) {
            toast("Dokunma servisi başlamadı: " + t);
        }
    }

    private void toast(final String s) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void forward(MotionEvent e) {
        IUserService s = svc;
        VirtualDisplay d = vd;
        if (s == null || d == null) {
            if (!warned && e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                warned = true;
                toast("Dokunma servisi henüz hazır değil");
            }
            return;
        }
        int n = Math.min(e.getPointerCount(), 10);
        int[] ids = new int[n];
        float[] xs = new float[n];
        float[] ys = new float[n];
        float sx = vw / (float) sv.getWidth();
        float sy = vh / (float) sv.getHeight();
        for (int i = 0; i < n; i++) {
            ids[i] = e.getPointerId(i);
            xs[i] = e.getX(i) * sx;
            ys[i] = e.getY(i) * sy;
        }
        try {
            s.touch(e.getAction(), n, ids, xs, ys, e.getDownTime(), e.getEventTime(),
                    d.getDisplay().getDisplayId());
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        try {
            DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
            int flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC
                    | DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
                    | 64; // SUPPORTS_TOUCH
            vd = dm.createVirtualDisplay("basik-ekran", vw, vh, 420, holder.getSurface(), flags);
        } catch (Throwable t) {
            toast("Sanal ekran açılamadı: " + t);
            return;
        }
        if (vd == null) {
            toast("Sanal ekran açılamadı");
            return;
        }
        launchGame();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        if (vd != null) {
            vd.release();
            vd = null;
        }
    }

    private void launchGame() {
        final int id = vd.getDisplay().getDisplayId();
        final boolean first = firstLaunch;
        firstLaunch = false;
        ex.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    if (first) Sh.run("am force-stop " + pkg);
                    Sh.Result r = Sh.run("am start --display " + id
                            + " -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -p " + pkg);
                    String low = r.out.toLowerCase();
                    if (r.code != 0 || low.contains("error") || low.contains("exception")) {
                        toast("Oyun sanal ekranda açılamadı: " + r.out);
                    }
                } catch (Throwable t) {
                    toast("Hata: " + t);
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        long now = System.currentTimeMillis();
        if (now - lastBack < 2000) {
            finish();
        } else {
            lastBack = now;
            toast("Çıkmak için tekrar geri bas");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (vd != null) {
            vd.release();
            vd = null;
        }
        try {
            Shizuku.unbindUserService(args, conn, true);
        } catch (Throwable ignored) {
        }
        ex.shutdown();
    }
}
