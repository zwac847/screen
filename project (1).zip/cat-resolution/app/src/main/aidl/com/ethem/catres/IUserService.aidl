package com.ethem.catres;

interface IUserService {
    void destroy() = 16777114;
    void exit() = 1;
    oneway void touch(int action, int count, in int[] ids, in float[] xs, in float[] ys,
            long downTime, long eventTime, int displayId) = 2;
}
